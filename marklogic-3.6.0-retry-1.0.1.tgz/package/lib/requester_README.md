## **LUX Custom Retry Logic**

- [Introduction](#introduction)
- [Background](#background)
- [Future Plans](#future-plans)
- [Version History](#version-history)
- [Customizations](#customizations)
  - [Timeout Management](#timeout-management)
  - [Vary Logic between Fast and Slow Request Types](#vary-logic-between-fast-and-slow-request-types)
  - [Broadened Qualifying Response Codes](#broadened-qualifying-response-codes)
  - [Added Messages to Monitor](#added-messages-to-monitor)
  - [System Overload Detection](#system-overload-detection)
  - [Adaptive Backoff](#adaptive-backoff)
  - [Server Backpressure Handling](#server-backpressure-handling)
- [Missing Capabilities](#missing-capabilities)

# Introduction
[./requester.js](./requester.js) was modified to have custom retry logic in order to reduce the likelihood of retry storms in LUX.

# Background
During AoA stress testing, retry storms were observed.  Given the rest of stack's request timeout was 60s, we elected to restrict the MarkLogic Node Client to the same (down from 120s), so as not to waste backend resources when the middle tier had already moved on.  As detailed in subsequent sections, the retry logic was customized beyond the 60s restriction.

The MarkLogic Node Client does not offer a means to customize the retry logic.  Thus, this offshoot was born.

# Future Plans

As of March 2026, it is our intent to roll this implementation out to production but to follow up afterwards with [MT 221](https://github.com/project-lux/lux-middletier/issues/221), "Determine the necessity of custom retry logic in the MarkLogic Node Client".  Our intent is to retest and either:

* Revert to the default retry logic by going back to the MarkLogic-released version; or,
* Request the ability to customize the retry logic without having to maintain and build the entire client.

# Version History

* 3.6.0-retry-1.0.0 (a.k.a., 3.6.0-retry-mod-01): Version used during AoA testing.
* 3.6.0-retry-1.0.1: Broadened support and improved separation of concerns by having `operation.currentAttemptStartTime` set in `authenticatedRequest` and `challengeRequest`; it is no longer set in `retryRequest`.  Elected to exclude `credentialsRequest` as the Kerberos implementation does not participate in this client's retry mechanism.

# Customizations

## Timeout Management

Tracks totalOperationTime vs 60-second requestor timeout

Skips retries when insufficient time remains

Caps retry delays to fit within remaining time budget

## Vary Logic between Fast and Slow Request Types

At present, the fast vs. slow distinction is hard-coded in `retryRequest`:

```javascript
// Determine request type characteristics from path
const path = operation.options.path.toLowerCase();
const isDocumentRequest = path.includes('/read.mjs');
const isTranslateRequest = path.includes('/translate.mjs');
const isFastRequest = isDocumentRequest || isTranslateRequest;
```

Sets different thresholds and retry parameters based on request type

Adaptive Timeouts & Thresholds

**Fast Requests:**

timeoutBuffer: 5s (can retry until 55s mark - more retry opportunities)

slowRequestThreshold: 10s (fail fast on slow responses)

maxRetries: 4 (more attempts since they're quick)

**Slow Requests:**

timeoutBuffer: 15s (can retry until 45s mark - fewer retries, more completion time)

slowRequestThreshold: 60s (in essence, disabling for slow request types)

maxRetries: 2 (fewer attempts since they're expensive)

## Broadened Qualifying Response Codes

Added 429 (too many requests) to the original list of 502, 503, and 504.

## Added Messages to Monitor

The following messages may now be sent to the [operation](/lib/operation.js)'s error listener from [./requester.js](./requester.js)'s `retryRequest` method, and thus on to the logs:

* `retry skipped - ${remainingTime}ms of ${timeoutBuffer}ms ${isFastRequest ? 'fast' : 'slow'} request timeout buffer remaining`
* `retry skipped - ${isFastRequest ? 'fast' : 'slow'} request took ${currentAttemptDuration}ms, indicating system overload`
* `retry failed - exceeded max ${maxRetries} attempts for ${isFastRequest ? 'fast' : 'slow'} request`

## System Overload Detection

Uses request-type aware duration thresholds

Fails fast when individual requests exceed expected duration

Intended to prevent retry storms during system stress

## Adaptive Backoff

Different base delays: 100ms (fast) vs 500ms (slow)

Request-type specific backoff multipliers

Jitter to prevent thundering herd effects

## Server Backpressure Handling

Respects Retry-After headers (with proper seconds→milliseconds conversion)

Uses Math.max(retryAfter, jitteredDelay) to honor server requests

# Missing Capabilities

The implementation is geared towards individual request retry logic but lacks system-level coordination features, such as:

1. Queue management (requests aren't queued, just delayed)
1. Circuit breaker pattern (no failure rate tracking across requests)
1. Average duration tracking (no moving averages to detect degradation)
1. Cross-request retry rate monitoring (each request retries independently)

Further, we could take the backend app server(s) queue status into account.  An initial stab at what that could look like is in the retry-mod-02 branch.